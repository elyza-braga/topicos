var btnLogin = document.querySelector("a[href='']");

btnLogin.setAttribute("data-toggle", "modal");
btnLogin.setAttribute("data-target", "#loginBox");